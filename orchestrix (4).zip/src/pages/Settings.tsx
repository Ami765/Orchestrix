import React from "react";
import { useWorkspaceStore, useUIStore } from "../store";

export default function Settings() {
  const db = useWorkspaceStore((state) => state.db);
  const saveSettings = useWorkspaceStore((state) => state.saveSettings);

  const {
    settingsTab,
    setSettingsTab,
    settingsForm,
    setSettingsForm,
  } = useUIStore();

  if (!db) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await saveSettings(
        {
          name: settingsForm.profileName,
          email: settingsForm.profileEmail,
          role: settingsForm.profileRole,
        },
        {
          name: settingsForm.workspaceName,
          defaultWorkflow: settingsForm.defaultWorkflow,
        }
      );
      alert("Settings updated successfully!");
    } catch (err) {
      console.error("Failed to save settings:", err);
      alert("Failed to save settings.");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="settings_view">
      <div className="border-b border-white/5 pb-4">
        <h1 className="text-xl font-display font-bold text-white">System Settings</h1>
        <p className="text-xs text-gray-400 mt-1">Manage profile properties, workspace defaults, connected models, and integrations.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left sidebar tabs */}
        <div className="flex flex-col gap-1 border-r border-white/5 pr-4">
          <button 
            type="button"
            onClick={() => setSettingsTab("profile")}
            className={`text-left px-3 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              settingsTab === "profile" ? "bg-indigo-600/10 border-l-2 border-indigo-500 text-indigo-400" : "text-gray-400 hover:text-white"
            }`}
          >
            Workspace Profile
          </button>
          <button 
            type="button"
            onClick={() => setSettingsTab("workspace")}
            className={`text-left px-3 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              settingsTab === "workspace" ? "bg-indigo-600/10 border-l-2 border-indigo-500 text-indigo-400" : "text-gray-400 hover:text-white"
            }`}
          >
            Workspace Details
          </button>
          <button 
            type="button"
            onClick={() => setSettingsTab("models")}
            className={`text-left px-3 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              settingsTab === "models" ? "bg-indigo-600/10 border-l-2 border-indigo-500 text-indigo-400" : "text-gray-400 hover:text-white"
            }`}
          >
            Primary AI Models
          </button>
        </div>

        {/* Right form container */}
        <div className="lg:col-span-3 bg-[#131826] border border-white/10 rounded-xl p-5 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
            
            {settingsTab === "profile" && (
              <div className="space-y-4 animate-fade-in">
                <div className="space-y-1">
                  <label className="text-xs text-gray-300 font-semibold block">Full Name</label>
                  <input 
                    type="text" 
                    value={settingsForm.profileName}
                    onChange={(e) => setSettingsForm({ profileName: e.target.value })}
                    className="w-full bg-[#0A0D16] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all font-sans"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-gray-300 font-semibold block">Email address</label>
                  <input 
                    type="email" 
                    value={settingsForm.profileEmail}
                    onChange={(e) => setSettingsForm({ profileEmail: e.target.value })}
                    className="w-full bg-[#0A0D16] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all font-sans"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-gray-300 font-semibold block">Account Role</label>
                  <select 
                    value={settingsForm.profileRole}
                    onChange={(e) => setSettingsForm({ profileRole: e.target.value })}
                    className="w-full bg-[#0A0D16] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all font-sans"
                  >
                    <option value="Reviewer">Reviewer</option>
                    <option value="Admin">Admin</option>
                    <option value="Analyst">Analyst</option>
                  </select>
                </div>
              </div>
            )}

            {settingsTab === "workspace" && (
              <div className="space-y-4 animate-fade-in">
                <div className="space-y-1">
                  <label className="text-xs text-gray-300 font-semibold block">Workspace Title</label>
                  <input 
                    type="text" 
                    value={settingsForm.workspaceName}
                    onChange={(e) => setSettingsForm({ workspaceName: e.target.value })}
                    className="w-full bg-[#0A0D16] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all font-sans"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-gray-300 font-semibold block">Default Deployment Directive</label>
                  <select 
                    value={settingsForm.defaultWorkflow}
                    onChange={(e) => setSettingsForm({ defaultWorkflow: e.target.value })}
                    className="w-full bg-[#0A0D16] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none focus:border-indigo-500 transition-all font-sans"
                  >
                    <option value="Full diligence review">Full diligence review</option>
                    <option value="Vendor risk scan">Vendor risk scan</option>
                    <option value="Covenant compliance check">Covenant compliance check</option>
                  </select>
                </div>
              </div>
            )}

            {settingsTab === "models" && (
              <div className="space-y-4 animate-fade-in">
                <div className="space-y-1">
                  <label className="text-xs text-gray-300 font-semibold block">Swarm Intelligence Model</label>
                  <select 
                    disabled
                    className="w-full bg-[#0A0D16] border border-white/10 rounded-lg p-2.5 text-xs text-gray-500 outline-none transition-all font-sans cursor-not-allowed"
                  >
                    <option>Gemini 3.5 Flash (Operational)</option>
                  </select>
                  <span className="text-[10px] text-indigo-400 font-mono block mt-1">Auto-calibrated for low latency and high reasoning consistency.</span>
                </div>
              </div>
            )}

            <div className="pt-4">
              <button type="submit" className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs font-semibold text-white select-none transition-all cursor-pointer">
                Save Workspace Changes
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
